function markers = getMarkers

markers = cell(12,1);

markers{1} = '+';
markers{2} = 'x';
markers{3} = 'o';
markers{4} = 'd';
markers{5} = 's';
markers{6} = 'v';
markers{7} = '<';
markers{8} = '>';
markers{9} = 'p';
markers{10} = 'h';
markers{11} = '*';
markers{12} = '.';













